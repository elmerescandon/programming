var mongoose = require('mongoose');
// Importar el archivo usuario que contiene la DB
var Usuario  = require('../models/Usuario');

var usuarioController = {};
usuarioController.list = function(req,res){
  Usuario.find({}).exec(function(err,usuarios){
    if (err){
      console.log('Error: ',err);
      return;
    }
    res.render('../views/usuario/index',{usuarios:usuarios});
  });
};

module.exports = usuarioController;
