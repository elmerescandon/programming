conn = new Mongo();

db = conn.getDB("utecdb");

db.usuarios.insert(
  [
    {nombre:'Raul',apellido:'Farfan',email:'elmer.escandon@utece.edu.pe',estado:'A',create_at:new Date('06/27/2020')}
  ]
)
